from project.wsgi import application

app = application